﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PreapreExam
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1(Bitmap bitmap, Size size)
        {
            InitializeComponent();
            pictureBox1.Image = bitmap;
            this.Size = size;
        }

        public string Content { get => label1.Text; set => label1.Text = value; }
        //public Size LableFontSize { get => label1.Size; set => label1.Size = value; }


    }
}
