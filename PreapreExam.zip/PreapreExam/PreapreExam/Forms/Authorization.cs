﻿using System.IO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace PreapreExam
{   
    public partial class Authoorization : Form
    {
        private string captchaText;
        private int width = 248;
        private int height = 63;
        private Random rnd = new Random();

        public Authoorization()
        {
            InitializeComponent();       

            captchaText = generateCaptchaCode(6);
            pictureBox1.Image = generateCaptchaImage();
        }
       
        private void BtEnter_Click(object sender, EventArgs e)
        {
            var filter = Program.logicAuth.UserRow(TbEmail.Text, TbPassword.Text);

            if (filter != null)
            {
                switch (filter.IDRole)
                {
                    case 1:
                        MessageBox.Show("Вы вошли как админ");
                        Administrator admin = new Administrator();
                        Hide();
                        admin.ShowDialog();
                        Show();
                        break;
                    case 2:
                        MessageBox.Show("Вы вошли как менеджер");
                        Manager manager = new Manager();
                        Hide();
                        manager.ShowDialog();
                        Show();
                        break;
                    case 3:
                        MessageBox.Show($"Добро пожаловать {filter.Lastname} {filter.Firstname} {filter.Patronymic}");
                        ListBook listBook = new ListBook();
                        Hide();
                        listBook.ShowDialog();
                        Show();
                        break;
                }
            }
            else
            {
                MessageBox.Show("Проверьте правильность введенных данных");                
            }
        }

        private string generateCaptchaCode(int charCount)
        {
            Random r = new Random();
            string s = "";
            for (int i = 0; i < charCount; i++)
            {
                int a = r.Next(3);
                int chr;
                switch (a)
                {
                    case 0:
                        chr = r.Next(0, 9);
                        s = s + chr.ToString();
                        break;
                    case 1:
                        chr = r.Next(65, 90);
                        s = s + Convert.ToChar(chr).ToString();
                        break;
                    case 2:
                        chr = r.Next(97, 122);
                        s = s + Convert.ToChar(chr).ToString();
                        break;
                }
            }
            return s;
        }

        private Bitmap generateCaptchaImage()
        {

            Bitmap bitmap = new Bitmap(width, height, PixelFormat.Format32bppArgb);
            Graphics g = Graphics.FromImage(bitmap);
            Rectangle rect = new Rectangle(0, 0, width, height);
            HatchBrush hatchBrush = new HatchBrush(HatchStyle.DottedGrid, Color.Aqua, Color.White);
            g.FillRectangle(hatchBrush, rect);

            GraphicsPath graphicPath = new GraphicsPath();
            graphicPath.AddString(captchaText, FontFamily.GenericMonospace, (int)FontStyle.Bold, 57, rect, null);
            hatchBrush = new HatchBrush(HatchStyle.Percent20, Color.Black, Color.DarkGreen);
            g.FillPath(hatchBrush, graphicPath);
            for (int i = 0; i < (int)(rect.Width * rect.Height / 50F); i++)
            {
                int x = rnd.Next(width);
                int y = rnd.Next(height);
                int w = rnd.Next(10);
                int h = rnd.Next(10);
                g.FillEllipse(hatchBrush, x, y, w, h);
            }
            hatchBrush.Dispose();
            g.Dispose();
            return bitmap;
        }



        private void BtExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LbGuest_Click(object sender, EventArgs e)
        {
            ListBook listBook = new ListBook();
            Hide();
            listBook.ShowDialog();
            Show();
        }

        private void LbReg_Click(object sender, EventArgs e)
        {
            Registration reg = new Registration();
            Hide();
            reg.ShowDialog();
            Show();
        }

        private void CbShowPass_CheckedChanged(object sender, EventArgs e)
        {
            if(CbShowPass.Checked)
            {
                TbEmail.UseSystemPasswordChar = true;
                TbPassword.UseSystemPasswordChar = true;
            }
            else
            {
                TbPassword.UseSystemPasswordChar = false;
                TbEmail.UseSystemPasswordChar = false;
            }
        }

        private void BtCaptcha_Click(object sender, EventArgs e)
        {
            captchaText = generateCaptchaCode(6);
            pictureBox1.Image = generateCaptchaImage();
        }
    }
}
