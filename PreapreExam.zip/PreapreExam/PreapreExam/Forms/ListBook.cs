﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PreapreExam
{
    public partial class ListBook : Form
    {       
        public ListBook()
        {
            InitializeComponent();
        }

        private void ListBook_Load(object sender, EventArgs e)
        {         
            for (int i = 0; i < 10; i++)
            {
                int sale = 20;
                double cost = 300;
                double costSale = cost - cost * sale / 100;

                var content = $"Наименование товара: Старческий гель {i} \n" +
                    $"Категория:  + {i} \n" +
                    $"Цена без скидки: {cost}\n" +
                    $"Скидка: + {sale}\n" +
                    $"Цена без скидки: + {costSale}\n";

                var control = new UserControl1(Resource1.ak12_gus_5808_free_13355_1080, new Size(flowLayoutPanelDATA.Width, 110));
                control.Content = content;
                flowLayoutPanelDATA.FlowDirection = FlowDirection.TopDown;
                flowLayoutPanelDATA.AutoScroll = true;
                flowLayoutPanelDATA.Controls.Add(control);
            }                                    
        }
    }    
}
