﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PreapreExam
{
    public partial class Registration : Form
    {
        PrepareExemDataSet.UserRow UserRow;
        PrepareExemDataSet.UserDataTable UserDataTable; 
        PrepareExemDataSetTableAdapters.UserTableAdapter UserTableAdapter = new PrepareExemDataSetTableAdapters.UserTableAdapter();
        PrepareExemDataSetTableAdapters.SexTableAdapter SexTableAdapter = new PrepareExemDataSetTableAdapters.SexTableAdapter();

        int IDSex;

        public Registration()
        {
            InitializeComponent();
            CbSex.DataSource = SexTableAdapter.GetData();
            CbSex.DisplayMember = "Title";
            CbSex.ValueMember = "ID";
        }

        private void BtExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtReg_Click(object sender, EventArgs e)
        {
            try
            {
                UserDataTable = UserTableAdapter.GetData();
                UserRow = (PrepareExemDataSet.UserRow)UserDataTable.NewRow();

                UserRow.Email = TbEmail.Text;
                UserRow.Password = TbPassword.Text;
                UserRow.Firstname = TbName.Text;
                UserRow.Lastname = TbLastname.Text;
                UserRow.Patronymic = TbPatronymic.Text;
                if (CbSex.Text == "М")
                    IDSex = 1;
                else if (CbSex.Text == "Ж")
                    IDSex = 2;
                UserRow.IDSex = IDSex;
                UserRow.PhoneNumber = TbPhone.Text;
                UserRow.IDRole = 3;
                Program.logicAuth.Reg(UserRow);
            }
            catch
            {

            }                    
        }
    }
}
