﻿namespace PreapreExam
{
    partial class Authoorization
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.TbEmail = new System.Windows.Forms.TextBox();
            this.TbPassword = new System.Windows.Forms.TextBox();
            this.BtEnter = new System.Windows.Forms.Button();
            this.BtExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LbReg = new System.Windows.Forms.Label();
            this.LbGuest = new System.Windows.Forms.Label();
            this.CbShowPass = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.BtCaptcha = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // TbEmail
            // 
            this.TbEmail.BackColor = System.Drawing.Color.White;
            this.TbEmail.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbEmail.Location = new System.Drawing.Point(112, 14);
            this.TbEmail.Name = "TbEmail";
            this.TbEmail.Size = new System.Drawing.Size(248, 34);
            this.TbEmail.TabIndex = 0;
            // 
            // TbPassword
            // 
            this.TbPassword.BackColor = System.Drawing.Color.White;
            this.TbPassword.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TbPassword.Location = new System.Drawing.Point(112, 57);
            this.TbPassword.Name = "TbPassword";
            this.TbPassword.Size = new System.Drawing.Size(248, 34);
            this.TbPassword.TabIndex = 1;
            // 
            // BtEnter
            // 
            this.BtEnter.BackColor = System.Drawing.Color.White;
            this.BtEnter.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.BtEnter.FlatAppearance.BorderSize = 0;
            this.BtEnter.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtEnter.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtEnter.Location = new System.Drawing.Point(112, 126);
            this.BtEnter.Name = "BtEnter";
            this.BtEnter.Size = new System.Drawing.Size(116, 35);
            this.BtEnter.TabIndex = 2;
            this.BtEnter.Text = "Войти";
            this.BtEnter.UseVisualStyleBackColor = false;
            this.BtEnter.Click += new System.EventHandler(this.BtEnter_Click);
            // 
            // BtExit
            // 
            this.BtExit.BackColor = System.Drawing.Color.Transparent;
            this.BtExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtExit.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtExit.Location = new System.Drawing.Point(230, 126);
            this.BtExit.Name = "BtExit";
            this.BtExit.Size = new System.Drawing.Size(130, 35);
            this.BtExit.TabIndex = 3;
            this.BtExit.Text = "Выход";
            this.BtExit.UseVisualStyleBackColor = false;
            this.BtExit.Click += new System.EventHandler(this.BtExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 26);
            this.label1.TabIndex = 4;
            this.label1.Text = "Почта";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 26);
            this.label2.TabIndex = 5;
            this.label2.Text = "Пароль";
            // 
            // LbReg
            // 
            this.LbReg.AutoSize = true;
            this.LbReg.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbReg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.LbReg.Location = new System.Drawing.Point(274, 105);
            this.LbReg.Name = "LbReg";
            this.LbReg.Size = new System.Drawing.Size(86, 18);
            this.LbReg.TabIndex = 6;
            this.LbReg.Text = "Регистарция";
            this.LbReg.Click += new System.EventHandler(this.LbReg_Click);
            // 
            // LbGuest
            // 
            this.LbGuest.AutoSize = true;
            this.LbGuest.Font = new System.Drawing.Font("Comic Sans MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LbGuest.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.LbGuest.Location = new System.Drawing.Point(109, 105);
            this.LbGuest.Name = "LbGuest";
            this.LbGuest.Size = new System.Drawing.Size(106, 18);
            this.LbGuest.TabIndex = 7;
            this.LbGuest.Text = "Войти как гость";
            this.LbGuest.Click += new System.EventHandler(this.LbGuest_Click);
            // 
            // CbShowPass
            // 
            this.CbShowPass.AutoSize = true;
            this.CbShowPass.Location = new System.Drawing.Point(17, 126);
            this.CbShowPass.Name = "CbShowPass";
            this.CbShowPass.Size = new System.Drawing.Size(89, 30);
            this.CbShowPass.TabIndex = 8;
            this.CbShowPass.Text = "Показывать\r\nпароль";
            this.CbShowPass.UseVisualStyleBackColor = true;
            this.CbShowPass.CheckedChanged += new System.EventHandler(this.CbShowPass_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(366, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(248, 63);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(366, 83);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(248, 34);
            this.textBox1.TabIndex = 11;
            // 
            // BtCaptcha
            // 
            this.BtCaptcha.BackColor = System.Drawing.Color.Transparent;
            this.BtCaptcha.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtCaptcha.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtCaptcha.Location = new System.Drawing.Point(405, 126);
            this.BtCaptcha.Name = "BtCaptcha";
            this.BtCaptcha.Size = new System.Drawing.Size(189, 35);
            this.BtCaptcha.TabIndex = 12;
            this.BtCaptcha.Text = "Сменить символы";
            this.BtCaptcha.UseVisualStyleBackColor = false;
            this.BtCaptcha.Click += new System.EventHandler(this.BtCaptcha_Click);
            // 
            // Authoorization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(806, 277);
            this.Controls.Add(this.BtCaptcha);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.CbShowPass);
            this.Controls.Add(this.LbGuest);
            this.Controls.Add(this.LbReg);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtExit);
            this.Controls.Add(this.BtEnter);
            this.Controls.Add(this.TbPassword);
            this.Controls.Add(this.TbEmail);
            this.Name = "Authoorization";
            this.Text = "ООО \"Крига\"";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TbEmail;
        private System.Windows.Forms.TextBox TbPassword;
        private System.Windows.Forms.Button BtEnter;
        private System.Windows.Forms.Button BtExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LbReg;
        private System.Windows.Forms.Label LbGuest;
        private System.Windows.Forms.CheckBox CbShowPass;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button BtCaptcha;
    }
}

