﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PreapreExam
{
    public class LogicAuthorization
    {
        private string Emaillog;
        private string Passlog;

        PrepareExemDataSetTableAdapters.UserTableAdapter UserTableAdapter = new PrepareExemDataSetTableAdapters.UserTableAdapter();
        PrepareExemDataSet.UserDataTable UserDataTable;

        public PrepareExemDataSet.UserRow UserRow(string Email, string Password)
        {
            Emaillog = Email;
            Passlog = Password;

            UserDataTable = UserTableAdapter.GetData();
            var  filter = UserDataTable.FirstOrDefault(x => x.Email == Emaillog && x.Password == Passlog);                               
                                     
            return filter;
        } 
        
        public void Reg(PrepareExemDataSet.UserRow UserRow)
        {            
            try
            {
                UserTableAdapter.Insert(UserRow.Email, UserRow.Password, UserRow.Firstname, UserRow.Lastname, UserRow.Patronymic, UserRow.IDSex, UserRow.PhoneNumber, UserRow.IDRole);
                MessageBox.Show("Вы успешно зарегестрировались");
            }
            catch
            {
                MessageBox.Show("Что-то пошло не так");
            }            
        }
    }
}
